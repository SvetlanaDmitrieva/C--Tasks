﻿//54.В матрице чисел найти сумму элементов главной диагонали
int matrixOrder, numSum;
Console.WriteLine("Введите порядок квадратной матрицы:");
matrixOrder = Int32.Parse(Console.ReadLine());
int[,] arrayNumber = new int[matrixOrder, matrixOrder];
FillArray(arrayNumber);
SumOfElements(arrayNumber, out numSum);
Console.WriteLine($"Сумма элементов главной диагонали матрицы равна {numSum}");
Console.WriteLine();
PrintArray(arrayNumber);
//
void FillArray(int[,] arrayN)
{
    for (int i = 0; i < arrayN.GetLength(0); i++)
        for (int j = 0; j < arrayN.GetLength(1); j++)
        {
            arrayN[i, j] = new Random().Next(1, 50);
        }
}
//
void PrintArray(int[,] arrayN)
{
    int flag = 0;
    for (int i = 0; i < arrayN.GetLength(0); i++)
    {
        for (int j = 0; j < arrayN.GetLength(1); j++)
        {
            Console.Write($"a[{i,2},{j,2}]={arrayN[i, j],4} |");
            flag++;
            if (flag % 3 == 0) Console.WriteLine();
        }
    }
    Console.WriteLine();
}
//
void SumOfElements(int[,] arrayN, out int sumNumbers)
{
    sumNumbers = 0;
    for (int i = 0; i < arrayN.GetLength(0); i++)
    {
        sumNumbers = sumNumbers + arrayN[i, i];
    }
}