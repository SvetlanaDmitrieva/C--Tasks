﻿// 59.В прямоугольной матрице найти строку с наименьшей суммой элементов.
int numberOfLines, numberOfColumns;
Console.WriteLine("Введите количество строк массива:");
numberOfLines = Int32.Parse(Console.ReadLine());
Console.WriteLine("Введите количество столбцов массива:");
numberOfColumns = Int32.Parse(Console.ReadLine());
int[,] matrixNumber = new int[numberOfLines, numberOfColumns];
int minSumLine, numberLine;
FillArray(matrixNumber);
SumElementsLines(matrixNumber, out minSumLine, out numberLine);
PrintArray(matrixNumber);
Console.WriteLine("Сумма элементов строки {0} равна {1}", numberLine, minSumLine);
//
void FillArray(int[,] arrayN)
{
    for (int i = 0; i < arrayN.GetLength(0); i++)
        for (int j = 0; j < arrayN.GetLength(1); j++)
        {
            arrayN[i, j] = new Random().Next(1, 100);
        }
}
//
void SumElementsLines(int[,] arrayN, out int sumOfLines, out int numberOfLines)
{
    int temp;
    numberOfLines = 0;
    sumOfLines = arrayN.GetLength(1) * 100;
    for (int i = 0; i < arrayN.GetLength(0); i++)
    {
        temp = 0;
        for (int j = 0; j < arrayN.GetLength(1); j++)
        {
            temp += arrayN[i, j];
        }
        if (sumOfLines > temp)
        {
            sumOfLines = temp;
            numberOfLines = i;
        }
    }
}
//
void PrintArray(int[,] arrayN)
{
    int flag = 0;
    for (int i = 0; i < arrayN.GetLength(0); i++)
        for (int j = 0; j < arrayN.GetLength(1); j++)
        {
            Console.Write("a[{0,2},{1,2}]= {2,5} | ", i, j, arrayN[i, j]);
            flag++;
            if (flag % 3 == 0) { Console.WriteLine(); }
        }
    Console.WriteLine();
}