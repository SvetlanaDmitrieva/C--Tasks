﻿//55.Дан целочисленный массив. Найти среднее арифметическое каждого из столбцов.
int numberOfLines, numberOfColumns;
Console.WriteLine("Введите количество строк массива:");
numberOfLines = Int32.Parse(Console.ReadLine());
Console.WriteLine("Введите количество столбцов массива:");
numberOfColumns = Int32.Parse(Console.ReadLine());
int[,] matrixNumber = new int[numberOfLines, numberOfColumns];
int[] sumOfElements = new int[numberOfColumns];
FillArray(matrixNumber);
SumElementsColumn(matrixNumber, sumOfElements);
Console.WriteLine("среднее арифметическое по столбцам ");
foreach (double element in sumOfElements)
{
    Console.Write("{0,9:F3}", element / (numberOfLines));
}
//
void FillArray(int[,] arrayN)
{
    for (int i = 0; i < arrayN.GetLength(0); i++)
        for (int j = 0; j < arrayN.GetLength(1); j++)
        {
            arrayN[i, j] = new Random().Next(1, 50);
        }
}
//
void SumElementsColumn(int[,] arrayN, int[] sumOfEles)
{
    for (int i = 0; i < arrayN.GetLength(0); i++)
    {
        for (int j = 0; j < arrayN.GetLength(1); j++)
        {
            Console.Write("{0,8:F3} ", arrayN[i, j]);
            sumOfEles[j] += arrayN[i, j];
        }
        Console.WriteLine();
    }
    Console.WriteLine();
}