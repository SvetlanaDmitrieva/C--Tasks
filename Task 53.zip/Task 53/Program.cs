﻿// 53.В двумерном массиве показать позиции числа, заданного пользователем или указать, 
//что такого элемента нет
int numberOfLines, numberOfColumns,numberDesired;
Console.WriteLine("Введите количество строк массива:");
numberOfLines = Int32.Parse(Console.ReadLine());
Console.WriteLine("Введите количество столбцов массива:");
numberOfColumns = Int32.Parse(Console.ReadLine());
Console.WriteLine("Укажите целое число для поиска в массиве:");
numberDesired= Int32.Parse(Console.ReadLine());

int[,] arrayNumber = new int[numberOfLines, numberOfColumns];
FillArray(arrayNumber);
ArraySearch(arrayNumber,numberDesired);
PrintArray(arrayNumber);
//
void FillArray(int[,] arrayN)
{
    for (int i = 0; i < arrayN.GetLength(0); i++)
        for (int j = 0; j < arrayN.GetLength(1); j++)
        {
            arrayN[i, j] = new Random().Next(11, 40);
        }
}
//
void PrintArray(int[,] arrayN)
{
    int flag = 0;
    for (int i = 0; i < arrayN.GetLength(0); i++)
    {
        for (int j = 0; j < arrayN.GetLength(1); j++)
        {
            Console.Write($"a[{i,2},{j,2}]= {arrayN[i,j],5} | ");
            flag++;
            if (flag % 3 == 0)  Console.WriteLine();
        }
    }
   Console.WriteLine();
}
//
void ArraySearch(int[,] arrayN, int numberSearch)
{
      for (int i = 0; i < arrayN.GetLength(0); i++)
        for (int j = 0; j < arrayN.GetLength(1); j++)
        {
            if(arrayN[i,j]==numberSearch){
                Console.Write($"Заданное число {arrayN[i,j]} найдено, " );
                Console.WriteLine($"позиция его первого вхождения - [{i}, {j}]");
                return;
            }
        }
        Console.WriteLine( $"Заданное число {numberSearch} не найдено.");
}