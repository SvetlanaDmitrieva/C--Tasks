﻿// 1.	Вывести квадрат числаn
string str;
int number, number2;
Console.WriteLine("Введите число :");
str = Console.ReadLine();
number=Int32.Parse(str);
number2=number*number;
System.Console.WriteLine("Квадрат числа {0} равен {1}", number ,number2 );
