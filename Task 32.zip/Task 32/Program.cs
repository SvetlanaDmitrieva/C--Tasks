﻿// 32.	Задать массив из 8 элементов, заполненных нулями и единицами вывести их на экран
int[] array = new int[8];
for (int i = 0; i < array.Length; i++)
{
    array[i] = new Random().Next(0, 2);
    Console.WriteLine("a[{0}]= {1,2}", i, array[i]);
}
